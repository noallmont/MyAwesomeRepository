/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package megaregexer;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Noall
 */
public class V6CURegexGuts {
    
    
    //Define the regex
    String cuServCheckin;
    String cuServCheckout = "^([0-9]*\\/[0-9]*\\/[0-9]*) [0-9]*:[0-9]*\\tOut\\"
            + "t([0-9A-Za-z]*) '.*', to Patron: ([0-9A-Za-z]*)\\tDue: (.*)$";
    String cuServRenew;
    
    static String cuLWSCheckin = "^([0-9]*\\/[0-9]*\\/[0-9]*) [0-9]*:[0-9]*"
            + "\\tIn\\t[0-9]*\\.[0-9]*\\.[0-9]*\\.[0-9]* \\(([0-9A-Za-z]*)\\)"
            + " ([0-9A-Za-z]*) '.*', by Patron: [0-9A-Za-z]*\\t.*$";
    
    static String cuLWSCheckout = "^([0-9]*\\/[0-9]*\\/[0-9]*) [0-9]*:[0-9]*"
            + "\\tOut\\t[0-9]*\\.[0-9]*\\.[0-9]*\\.[0-9]* \\(([0-9A-Za-z]*)\\) "
            + "([0-9A-Za-z]*) '.*', to Patron: ([0-9A-Za-z]*)\\tDue: (.*)$";
    
    String cuLWSRenew = "^([0-9]*\\/[0-9]*\\/[0-9]*) [0-9]*:[0-9]*\\tRenewed\\"
            + "t[0-9]*\\.[0-9]*\\.[0-9]*\\.[0-9]* \\(([0-9A-Za-z]*)\\) ([0-9A-Za-z]*) .*$";
    String cuWebCheckin;
    String cuWebCheckout = "^([0-9]*\\/[0-9]*\\/[0-9]*) [0-9]*:[0-9]*\\"
            + "tWEB Out\\t([0-9A-Za-z]*) '.*', to Patron: ([0-9A-Za-z]*)\\tDue: (.*)$";
    String cuWebRenew;
    
    static boolean b;
    
    public static void cuLWSCheckouter(String s, ArrayList l) {
        
        b = false;
        
        Pattern pattern = Pattern.compile(cuLWSCheckout);

        Matcher matcher = pattern.matcher(s);

        while (matcher.find()) {
            
            l.<String>add("Switch Site:" + matcher.group(2));
            l.<String>add("." + matcher.group(5));
            l.<String>add(matcher.group(4));
            l.<String>add(matcher.group(3));
            l.<String>add("x");
                    
            
            System.out.println("Switch Site:" + matcher.group(2));
            System.out.println("." + matcher.group(5));
            System.out.println(matcher.group(4));
            System.out.println(matcher.group(3));
            System.out.println("x");
            
        } 
        if(s.matches(cuLWSCheckout)){
            b = true;
        }
        
    }
    
    public static void cuLWSCheckinner(String s, ArrayList l) {
        
        b = false;
        
        Pattern pattern = Pattern.compile(cuLWSCheckin);
        
        Matcher matcher = pattern.matcher(s);
        
        while(matcher.find()) {
            
            l.<String>add("Switch Site:" + matcher.group(2));
            l.<String>add("." + matcher.group(1));
            l.<String>add(matcher.group(3));
            l.<String>add("x");
            
            System.out.println("Switch Site:" + matcher.group(2));
            System.out.println("." + matcher.group(1));
            System.out.println(matcher.group(3));
            System.out.println("X");
                        
        }
        if(s.matches(cuLWSCheckin)){
            b = true;
        }
        
        
        
    }
    
    
    
  
    
    
}
