/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package megaregexer;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import static megaregexer.V6RegexGuts.b;

/**
 *
 * @author Noall
 */
public class V6RegexOmitter {
    
    static boolean b; //if the pattern matches, this will reset the loop
    
    public static void checkOuter(String s, ArrayList l) {
        //b needs to be set to false in case it was set to true earlier
        b = false;

        Pattern pattern = Pattern.compile("^([0-9]*\\/[0-9]*\\/[0-9]*) "
                + "[0-9]*:[0-9]*\\tOut\\t([0-9A-Za-z]*) '.*', to Patron: ([0-9A-Za-z]*)\\tDue: (.*)$");

        Matcher matcher = pattern.matcher(s);

        while (matcher.find()) {
                        
       
            l.<String>add(matcher.group(2));
        
                    
            //this just prints to console. it doesn't actually DO anything        
           
            System.out.println(matcher.group(2));
       
            
        
            }
        //This sets b to true, allowing the while loop in the main method to continue
            if (s.matches("^([0-9]*\\/[0-9]*\\/[0-9]*) "
                + "[0-9]*:[0-9]*\\tOut\\t([0-9A-Za-z]*) '.*', to Patron: ([0-9A-Za-z]*)\\tDue: (.*)$")) {
                b = true;   
                
            }
        }
    
    
    
}
