/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package megaregexer;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Noall
 */
public class V6RegexGuts {
    
    static boolean b; //if the pattern matches, this will reset the loop
    
   
    
    public static void checkOuter(String s, ArrayList l) {
        //b needs to be set to false in case it was set to true earlier
        b = false;

        Pattern pattern = Pattern.compile("^([0-9]*\\/[0-9]*\\/[0-9]*) "
                + "[0-9]*:[0-9]*\\tOut\\t([0-9A-Za-z]*) '.*', to Patron: ([0-9A-Za-z]*)\\tDue: (.*)$");

        Matcher matcher = pattern.matcher(s);

        while (matcher.find()) {
            
            
            l.<String>add("." + matcher.group(4));
            l.<String>add(matcher.group(3));
            l.<String>add(matcher.group(2));
            l.<String>add("x");
                    
            //this just prints to console. it doesn't actually DO anything        
            System.out.println("." + matcher.group(4));
            System.out.println(matcher.group(3));
            System.out.println(matcher.group(2));
            System.out.println("x");
            
        
            }
        //This sets b to true, allowing the while loop in the main method to continue
            if (s.matches("^([0-9]*\\/[0-9]*\\/[0-9]*) "
                + "[0-9]*:[0-9]*\\tOut\\t([0-9A-Za-z]*) '.*', to Patron: ([0-9A-Za-z]*)\\tDue: (.*)$")) {
                b = true;   
                
            }
        }
    

    public static void checkInner(String s, ArrayList l) {
        
        b = false;

        Pattern pattern = Pattern.compile("^([0-9]*\\/[0-9]*\\/[0-9]*)"
                + "\\s[0-9]*:[0-9]*\\tIn\\t([0-9A-Za-z]*).*$");

        Matcher matcher = pattern.matcher(s);

        while (matcher.find()) {
            
            
            l.<String>add("." + matcher.group(1));
            l.<String>add(matcher.group(2));
            l.<String>add("x");

            System.out.println("." + matcher.group(1));
            System.out.println(matcher.group(2));
            System.out.println("x");
            
            
                
            }
        if(s.matches("^([0-9]*\\/[0-9]*\\/[0-9]*)"
                + "\\s[0-9]*:[0-9]*\\tIn\\t([0-9A-Za-z]*).*$")){
                
                b = true;
        }
    }

    public static void reNewer(String s, ArrayList l) {
        
        b = false;

        Pattern pattern = Pattern.compile("^([0-9]*\\/[0-9]*\\/[0-9]*) "
                + "[0-9]*:[0-9]*\\tRenewed\\t([0-9A-Za-z]*) (.*)$");

        Matcher matcher = pattern.matcher(s);

        while (matcher.find()) {
            
            l.<String>add("R " + matcher.group(2));
            l.<String>add("x");

            System.out.println("R " + matcher.group(2));
            System.out.println("x");
            
            
                
                
            }
        if(s.matches("^([0-9]*\\/[0-9]*\\/[0-9]*) "
                + "[0-9]*:[0-9]*\\tRenewed\\t([0-9A-Za-z]*) (.*)$")){
                b = true;
        }
    }
    
    public static void lwsRenewer(String s, ArrayList l) {
        
        b = false;
        
        Pattern pattern = Pattern.compile("^([0-9]*\\/[0-9]*\\/[0-9]*)"
                + " [0-9]*:[0-9]*\\tRenewed\\t[0-9]*\\.[0-9]*\\.[0-9]*\\.[0-9]* "
                + "\\(([0-9A-Za-z]*)\\) ([0-9A-Za-z]*) .*$");

        Matcher matcher = pattern.matcher(s);

        while (matcher.find()) {
            
            l.<String>add("R " + matcher.group(3));
            l.<String>add("x");

            System.out.println("R " + matcher.group(3));
            System.out.println("x");
            
        }
        if(s.matches("^([0-9]*\\/[0-9]*\\/[0-9]*)"
                + " [0-9]*:[0-9]*\\tRenewed\\t[0-9]*\\.[0-9]*\\.[0-9]*\\.[0-9]* "
                + "\\(([0-9A-Za-z]*)\\) ([0-9A-Za-z]*) .*$")){
            b = true;
            
        }
        
    }
    
    public static void lwsCheckouter(String s, ArrayList l) {
        
        b = false;
        
        Pattern pattern = Pattern.compile("^([0-9]*\\/[0-9]*\\/[0-9]*) "
                + "[0-9]*:[0-9]*\\tOut\\t[0-9]*\\.[0-9]*\\.[0-9]*\\.[0-9]* "
                + "\\(([0-9A-Za-z]*)\\) ([0-9A-Za-z]*) '.*', to Patron: ([0-9A-Za-z]*)\\tDue: (.*)$");

        Matcher matcher = pattern.matcher(s);

        while (matcher.find()) {
            
            l.<String>add("." + matcher.group(5));
            l.<String>add(matcher.group(4));
            l.<String>add(matcher.group(3));
            l.<String>add("x");
                    
                    
            System.out.println("." + matcher.group(5));
            System.out.println(matcher.group(4));
            System.out.println(matcher.group(3));
            System.out.println("x");
            
        } 
        if(s.matches("^([0-9]*\\/[0-9]*\\/[0-9]*) "
                + "[0-9]*:[0-9]*\\tOut\\t[0-9]*\\.[0-9]*\\.[0-9]*\\.[0-9]* "
                + "\\(([0-9A-Za-z]*)\\) ([0-9A-Za-z]*) '.*', to Patron: ([0-9A-Za-z]*)\\tDue: (.*)$")){
            b = true;
        }
        
    }
    
    public static void lwsCheckinner (String s, ArrayList l) {
        
        b = false;       
        
        Pattern pattern = Pattern.compile("^([0-9]*\\/[0-9]*\\/[0-9]*) "
                + "[0-9]*:[0-9]*\\tIn\\t[0-9]*\\.[0-9]*\\.[0-9]*\\.[0-9]* "
                + "\\(([0-9A-Za-z]*)\\) ([0-9A-Za-z]*) '.*', by Patron: [0-9A-Za-z]*\\t.*$");

        Matcher matcher = pattern.matcher(s);

        while (matcher.find()) {
            
            
            l.<String>add("." + matcher.group(1));
            l.<String>add(matcher.group(3));
            l.<String>add("x");

            System.out.println("." + matcher.group(1));
            System.out.println(matcher.group(3));
            System.out.println("x");
            
            
                
            }
        if (s.matches("^([0-9]*\\/[0-9]*\\/[0-9]*) [0-9]*:[0-9]*"
                    + "\\tIn\\t[0-9]*\\.[0-9]*\\.[0-9]*\\.[0-9]* "
                    + "\\(([0-9A-Za-z]*)\\) ([0-9A-Za-z]*) '.*', by Patron: [0-9A-Za-z]*\\t.*$")) {
                b = true;
            
            
        }
        
    }
    
    public static void webCheckouter(String s, ArrayList l) {
        
        b = false;
        
        Pattern pattern = Pattern.compile("^([0-9]*\\/[0-9]*\\/[0-9]*) "
                + "[0-9]*:[0-9]*\\tWEB Out\\t([0-9A-Za-z]*)"
                + " '.*', to Patron: ([0-9A-Za-z]*)\\tDue: (.*)$");
        
        Matcher matcher = pattern.matcher(s);

        while (matcher.find()) {
            
            
            l.<String>add("." + matcher.group(4));
            l.<String>add(matcher.group(3));
            l.<String>add(matcher.group(2));
            l.<String>add("x");
                    
            //this just prints to console. it doesn't actually DO anything        
            System.out.println("." + matcher.group(4));
            System.out.println(matcher.group(3));
            System.out.println(matcher.group(2));
            System.out.println("x");       
        
        }
        if(s.matches("^([0-9]*\\/[0-9]*\\/[0-9]*) "
                + "[0-9]*:[0-9]*\\tWEB Out\\t([0-9A-Za-z]*)"
                + " '.*', to Patron: ([0-9A-Za-z]*)\\tDue: (.*)$")){
            
            b = true;
        }
    }    
    
    public static void webCheckinner(String s, ArrayList l) {
        
        b = false;
        
        Pattern pattern = Pattern.compile("^([0-9]*\\/[0-9]*\\/[0-9]*)"
                + " [0-9]*:[0-9]*\\tWEB In\\t([0-9A-Za-z]*)"
                + " '.*', by Patron: [0-9A-Za-z]*\\t.*$");
        
        Matcher matcher = pattern.matcher(s);
        
        while (matcher.find()) {
            
            
            l.<String>add("." + matcher.group(1));
            l.<String>add(matcher.group(2));
            l.<String>add("x");

            System.out.println("." + matcher.group(1));
            System.out.println(matcher.group(2));
            System.out.println("x");
                
            }
        if (s.matches("^([0-9]*\\/[0-9]*\\/[0-9]*)"
                + " [0-9]*:[0-9]*\\tWEB In\\t([0-9A-Za-z]*)"
                + " '.*', by Patron: [0-9A-Za-z]*\\t.*$")) {
            
            b = true;
        }
        
        
        
    }
    
    public static void webRenewer(String s, ArrayList l) {
        
        b = false;
        
        Pattern pattern = Pattern.compile("^([0-9]*\\/[0-9]*\\/[0-9]*) "
                + "[0-9]*:[0-9]*\\tWEB Renewed\\t([0-9A-Za-z]*) (.*)$");
        
        Matcher matcher = pattern.matcher(s);

        while (matcher.find()) {
            
            l.<String>add("R " + matcher.group(3));
            l.<String>add("x");

            System.out.println("R " + matcher.group(3));
            System.out.println("x");
    }
        
    if(s.matches("^([0-9]*\\/[0-9]*\\/[0-9]*) "
                + "[0-9]*:[0-9]*\\tWEB Renewed\\t([0-9A-Za-z]*) (.*)$")){
        
        b = true;
    }  
        
    }        
	
}
    

