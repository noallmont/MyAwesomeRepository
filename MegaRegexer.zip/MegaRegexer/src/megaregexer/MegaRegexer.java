/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package megaregexer;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;
import static megaregexer.V6CURegexGuts.cuLWSCheckinner;
import static megaregexer.V6CURegexGuts.cuLWSCheckouter;
import static megaregexer.V6RegexGuts.checkInner;
import static megaregexer.V6RegexGuts.checkOuter;
import static megaregexer.V6RegexGuts.lwsCheckinner;
import static megaregexer.V6RegexGuts.lwsCheckouter;
import static megaregexer.V6RegexGuts.reNewer;
import static megaregexer.V6RegexGuts.webCheckinner;
import static megaregexer.V6RegexGuts.webCheckouter;
import static megaregexer.V6RegexGuts.webRenewer;


/**
 *
 * @author Noall
 */
public class MegaRegexer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        ArrayList<String> printList = new ArrayList<>();
		
	Path currentRelativePath = Paths.get("");
	String p = currentRelativePath.toAbsolutePath().toString();
	System.out.println("Current relative path is: " + p);
        
        File file  = new File(p + "/FinishedScript/transaction_script.txt");
        
        
        
        Scanner scan  = new Scanner(System.in);
        
        System.out.println("Enter something! Either 'A' or 'B'");
        
        String theInput;
        theInput = scan.next();
        
        System.out.println("You entered " + theInput);
        
        if(theInput.equals("A")){
            
            try{
            
            
            //Reads the log input file
            FileInputStream fstream = new FileInputStream(p + "/GetTransactions/regTest1.txt");
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            
            //Each strLine is one line of the log file
            String strLine;
            
            //Need to have some sort of OMIT action here
            
            while((strLine = br.readLine()) != null) {
                
                webCheckinner(strLine, printList);
                
                if(V6RegexGuts.b == true){
                    continue;
                }
                
                webRenewer(strLine, printList);
                
                if(V6RegexGuts.b == true){
                    continue;
                }
                
                webCheckouter(strLine, printList);
                
                if(V6RegexGuts.b == true){
                    continue;
                }
                
                
                
                
                
                lwsCheckinner(strLine, printList);
                
                if(V6RegexGuts.b == true){
                    continue;
                }
                
                lwsCheckouter(strLine, printList);
                
                if(V6RegexGuts.b == true){
                    continue;
                }
                //if strLine matches checkout, checkout transaction script is output
                checkOuter(strLine, printList);
                
                if(V6RegexGuts.b == true){
                    continue;
                }
                //if strLine matches checkin, checkin transaction script is output
                checkInner(strLine, printList);
                
                if(V6RegexGuts.b == true){
                    continue;
                }
                //if strLine matches renew, renew transaction script is output
                reNewer(strLine, printList);
                
                if(V6RegexGuts.b == true){
                    continue;
                }
            }
            in.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        
        
        
            
            
        
            
            
        
        }else if(theInput.equals("B")){
            
            try {
                FileInputStream fstream = new FileInputStream(p + "/GetTransactions/regTest1.txt");
                DataInputStream in  = new DataInputStream(fstream);
                BufferedReader br = new BufferedReader(new InputStreamReader(in));
                
            //Remember, each strLine SHOULD BE one line of the log file
            String strLine;
            
            while((strLine = br.readLine()) != null){
                
                cuLWSCheckouter(strLine, printList);
                
                if(V6CURegexGuts.b == true){
                    continue;
            
            }
                cuLWSCheckinner(strLine, printList);
                
                if(V6CURegexGuts.b == true){
                    continue;
                }
                
            } 
                
                
            }
            
            catch(Exception e){
                e.printStackTrace();
            }
            
            
            
            
            
            
        }else{
            
            System.out.println(theInput + "is not recognized");
        }
        
        //We need some sort of OMIT capability
        
        
        
        
        
        //This adds the necessary headers and other info to the script
        try(PrintWriter pw = new PrintWriter(new FileOutputStream(file))){
            
            pw.println(".");
            pw.println("..");
            
            for(String str : printList) {
                
                pw.println(str);
                
            }
            pw.println(".");
            
        }
        catch(Exception e){
            e.printStackTrace();
        }
        
        
        
    }   
}
