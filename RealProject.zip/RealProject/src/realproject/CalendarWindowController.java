/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realproject;

import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import static realproject.AppointmentWindowController.apptListToTable;

/**
 * FXML Controller class
 *
 * @author Noall
 */
public class CalendarWindowController implements Initializable {
    
    @FXML
    private TableView<ApptFormHandler> calTable;

    @FXML
    private TableColumn<ApptFormHandler, String> calName;

    @FXML
    private TableColumn<ApptFormHandler, String> calAppt;

    @FXML
    private TableColumn<ApptFormHandler, String> calDescription;

    @FXML
    private TableColumn<ApptFormHandler, String> calStart;

    @FXML
    private TableColumn<ApptFormHandler, String> calEnd;

    @FXML
    private TableColumn<ApptFormHandler, String> calLocation;

    @FXML
    private TableColumn<ApptFormHandler, String> calContact;

    @FXML
    private RadioButton calWeek;

    @FXML
    private RadioButton calMonth;
    
     @FXML
    private DatePicker calDate;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
                
        calName.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        calAppt.setCellValueFactory(new PropertyValueFactory<>("title"));
        calDescription.setCellValueFactory(new PropertyValueFactory<>("description"));
        calStart.setCellValueFactory(new PropertyValueFactory<>("start"));
        calEnd.setCellValueFactory(new PropertyValueFactory<>("end"));
        calLocation.setCellValueFactory(new PropertyValueFactory<>("location"));
        calContact.setCellValueFactory(new PropertyValueFactory<>("contact"));

        calDate.setValue(LocalDate.now());
        
        calMonth.setSelected(true);
        calWeek.setSelected(false);
        
        calTable.getItems().setAll(calListToTable());
        // TODO
    } 
    
    
    public ArrayList<ApptFormHandler> calListToTable() {

        ArrayList<ApptFormHandler> tableViewPopulator = new ArrayList<>();

        Integer month = calDate.getValue().getMonthValue();
        
        
        
        if (calMonth.isSelected()){
        
        try {
            PreparedStatement ps = MyConnector.getConn().prepareStatement("SELECT customer.customerName, appointment.customerId, "
                    + "appointment.appointmentId, appointment.title, appointment.description, appointment.location, "
                    + "appointment.contact, appointment.url, appointment.start, appointment.end "
                    + "FROM customer, appointment WHERE appointment.customerId = customer.customerId AND month(start) =?;");

            
            
        
            
            
            ps.setString(1, month.toString());

            System.out.println(ps.toString());
            
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                String tempCustName = rs.getString("customer.customerName");
                String tempCustId = rs.getString("appointment.customerId");
                String tempApptId = rs.getString("appointment.appointmentId");
                String tempTitle = rs.getString("appointment.title");
                String tempDescription = rs.getString("appointment.description");
                String tempLocation = rs.getString("appointment.location");
                String tempContact = rs.getString("appointment.contact");
                String tempURL = rs.getString("appointment.url");
                Timestamp tempStart = rs.getTimestamp("appointment.start");                              //start, end url
                Timestamp tempEnd = rs.getTimestamp("appointment.end");

                ZonedDateTime uniStart = ZonedDateTime.of(tempStart.toLocalDateTime(), ZoneId.of("UTC"));  //179 through 189 are for converting timestamp from database to UTC timestamp

                uniStart = uniStart.withZoneSameInstant(ZoneId.systemDefault());

                ZonedDateTime uniEnd = ZonedDateTime.of(tempEnd.toLocalDateTime(), ZoneId.of("UTC"));

                uniEnd = uniEnd.withZoneSameInstant(ZoneId.systemDefault());

                tempStart = Timestamp.valueOf(uniStart.toLocalDateTime());   //
                tempEnd = Timestamp.valueOf(uniEnd.toLocalDateTime());  //We'll to the opposite of this when putting information back into the database  - From System default TO UTC

                tableViewPopulator.add(new ApptFormHandler(tempCustName, tempCustId, tempApptId, tempTitle,
                        tempDescription, tempLocation, tempContact, tempURL, tempStart, tempEnd));

                

            }
        } catch (Exception e) {

        }
        
        }else{ //Week view
            LocalDateTime d = LocalDateTime.of(calDate.getValue(), LocalTime.MIN);// 1 minute after midnight
            
            LocalDateTime dw = d.plusDays(7);// 11:59 pm
            
            try {
            PreparedStatement ps = MyConnector.getConn().prepareStatement("SELECT customer.customerName, appointment.customerId, "
                    + "appointment.appointmentId, appointment.title, appointment.description, appointment.location, "
                    + "appointment.contact, appointment.url, appointment.start, appointment.end "
                    + "FROM customer, appointment WHERE appointment.customerId = customer.customerId AND start BETWEEN ? and ?;");
            
            

            
            
       
            
            
            ps.setTimestamp(1, Timestamp.valueOf(d));
            
            ps.setTimestamp(2, Timestamp.valueOf(dw));

            System.out.println("Let's populate this table!");
            //we make it this far at least!

            System.out.println(ps.toString());
            
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                String tempCustName = rs.getString("customer.customerName");
                String tempCustId = rs.getString("appointment.customerId");
                String tempApptId = rs.getString("appointment.appointmentId");
                String tempTitle = rs.getString("appointment.title");
                String tempDescription = rs.getString("appointment.description");
                String tempLocation = rs.getString("appointment.location");
                String tempContact = rs.getString("appointment.contact");
                String tempURL = rs.getString("appointment.url");
                Timestamp tempStart = rs.getTimestamp("appointment.start");                             
                Timestamp tempEnd = rs.getTimestamp("appointment.end");

                ZonedDateTime uniStart = ZonedDateTime.of(tempStart.toLocalDateTime(), ZoneId.of("UTC"));  

                uniStart = uniStart.withZoneSameInstant(ZoneId.systemDefault());

                ZonedDateTime uniEnd = ZonedDateTime.of(tempEnd.toLocalDateTime(), ZoneId.of("UTC"));

                uniEnd = uniEnd.withZoneSameInstant(ZoneId.systemDefault());

                tempStart = Timestamp.valueOf(uniStart.toLocalDateTime());   //
                tempEnd = Timestamp.valueOf(uniEnd.toLocalDateTime());  

                tableViewPopulator.add(new ApptFormHandler(tempCustName, tempCustId, tempApptId, tempTitle,
                        tempDescription, tempLocation, tempContact, tempURL, tempStart, tempEnd));

                System.out.println("After appListToTable, did we make it??");

            }
        } catch (Exception e) {

        }
        
        }
        
        return tableViewPopulator;
    }
    
    @FXML
    public void selectMonth(){
                    
        calWeek.setSelected(false);
        
        calTable.getItems().setAll(calListToTable());

    }
    
    @FXML
    public void selectWeek(){
        
        calMonth.setSelected(false);
        
        calTable.getItems().setAll(calListToTable());
        
    }
    
    @FXML
    public void refreshCal(){
        if (calMonth.isSelected()){
            
            selectMonth();
        
    }else{
        selectWeek();
        }
        
    }     
    
    
}
