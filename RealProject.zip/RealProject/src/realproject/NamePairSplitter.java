/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realproject;

/**
 *
 * @author Noall
 */

//This method splits the Name field from the database into the first name and last name
public class NamePairSplitter {
    
    public static SplitName<String> fullName(String s) {
		
		String last = s.substring(0, s.indexOf(","));
		String first = s.substring(s.indexOf(",") + 1, s.length()).trim();
		
		return new SplitName<>(first, last);
		
	}
    
}

class SplitName<T> {
	private final T n_first;
	private final T n_second;
	
	public SplitName(T first, T second) {
		n_first = first;
		n_second = second;
	}
	public T first() {
		return n_first;
	}
	public T second() {
		return n_second;
	}
}