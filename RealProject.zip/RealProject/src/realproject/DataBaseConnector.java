/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realproject;

import java.sql.*;

/**
 *
 * @author Noall
 */
public class DataBaseConnector {
//    private String url = "jdbc:mysql://52.206.157.109/U03p8Q";
//    private String userName = "U03pp8Q";
//    private String passWord = "53688046122";
//    //Connection conn = null;
//    
//    
//   public Connection getConnection() throws SQLException {
//        try {
//            Connection conn = DriverManager.getConnection(url, userName, passWord);
//            conn.setAutoCommit(false);
//            System.out.println("Connected to database");
//            
//        }
//        catch (Exception e){
//            
//        }
//   }
   
}
        
    
    

