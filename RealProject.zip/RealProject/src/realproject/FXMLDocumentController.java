/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realproject;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
//import simpledbtester.MyConnector

/**
 *
 * @author Noall
 */
public class FXMLDocumentController implements Initializable {
    
    private static String currentUser;
    
    @FXML
    private Label loginLabel;
    
    @FXML
    private Label passwordLabel;

    private ResourceBundle bundle;
    private Locale locale;
    
    @FXML
    private TextField login_field;
    
    @FXML
    private TextField password_field;
    
    
    @FXML
    private void handleButtonAction(ActionEvent event) throws IOException {
        
        String login = login_field.getText();
        String password = password_field.getText();
        
        Statement stmt = null;
        
        MyConnector myConn = new MyConnector();
        
        boolean goodCredentials;
               
        myConn.doTheConnection();
        
        try {
            MyConnector.getConn();
            
            PreparedStatement ps = MyConnector.getConn().prepareStatement("SELECT * FROM user WHERE userName = ?");
            ps.setString(1, login);// this replaces the wildcard in the select statement with the login variable
            ResultSet rs = ps.executeQuery(); //this retuns the results of the query from database we made with ps
            
            if (rs.next()){
                String goodPW = rs.getString("password");
                if (password.equals(goodPW)) {
                    //go to next scene, login is successful
                    System.out.println("Password validated!!!!!!!!!");
                    
                    currentUser = login;
                    
                    loginToFile();
                    reminders();
                    
                    try {
                        
                        
                        Stage oldWindow = (Stage)login_field.getScene().getWindow();
                        oldWindow.close();
                        
                        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("HomeScene.fxml"));
                        Parent root1 = (Parent) fxmlLoader.load();
                        Stage stage = new Stage();
                        stage.setTitle("HomeScene");
                        stage.setScene(new Scene(root1));
                        stage.show();
                    } catch (Exception e) {
                        System.out.println("Can't open the window!");
                    }
                    
                    
                }
                else {
                    System.out.println("Incorrect");//this means PW is incorrect
                    
                    Alert alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Incorrect Credentials");
                    alert.setHeaderText(null);
                    alert.setContentText("Login and/or Password entered was incorrect. Please try again.");
                    
                    alert.showAndWait();
                }
            }
            else{
                //Need to add message here for invalid login info
                System.out.println("WRONG!!!!");//This means UN is wrong
                
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Incorrect Credentials");
                alert.setHeaderText(null);
                alert.setContentText("Login and/or Password entered was incorrect. Please try again.");
                    
                alert.showAndWait();
            }
        }
        catch (SQLException e){
            System.out.println("Invalid SQL");
        }
        
        System.out.println(login);
        System.out.println(password);
    }
    
    @FXML
//    private void loadLang(String lang) {
//        locale = new Locale(lang);
//        bundle = ResourceBundle.getBundle("realproject.Bundle", locale);
//        label.setText(bundle.getString("%login.text"));
//    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        locale = Locale.getDefault();
        //locale = new Locale("es", "US");
        bundle = ResourceBundle.getBundle("realproject.Bundle", locale);
        loginLabel.setText(bundle.getString("login.default"));
        passwordLabel.setText(bundle.getString("password.default"));
    }

    public static String getCurrentUser() {
        return currentUser;
    }
    
    
    public static void loginToFile() {
        
        try (BufferedWriter logWriter = new BufferedWriter(new FileWriter("log_file.TXT", true))) {
 
            logWriter.write(getCurrentUser() + " logged in at " + LocalDateTime.now().toString());
            logWriter.newLine();

    }catch (IOException e) {

        }
 
    }
    
    public static void logoutToFile() {
        
        try (BufferedWriter logWriter = new BufferedWriter(new FileWriter("log_file.TXT", true))) {
 
            logWriter.write(getCurrentUser() + " logged out at " + LocalDateTime.now().toString());
            logWriter.newLine();

    }catch (IOException e) {

        }
 
    }
    
    public void reminders() {

               
        try {
            PreparedStatement ps = MyConnector.getConn().prepareStatement("SELECT customer.customerName, appointment.customerId, "
                    + "appointment.appointmentId, appointment.title, appointment.description, appointment.location, "
                    + "appointment.contact, appointment.url, appointment.start, appointment.end "
                    + "FROM customer, appointment WHERE appointment.customerId = customer.customerId AND start BETWEEN ? AND ?;");
            
            ZonedDateTime uniStart = ZonedDateTime.of(LocalDateTime.now(), ZoneId.systemDefault());  //179 through 189 are for converting timestamp from database to UTC timestamp

            uniStart = uniStart.withZoneSameInstant(ZoneId.of("UTC"));

            
            Timestamp tempStart = Timestamp.valueOf(uniStart.toLocalDateTime());   //
            Timestamp tempEnd = Timestamp.valueOf(uniStart.toLocalDateTime().plusMinutes(15));  //We'll to the opposite of this when putting information back into the database  - From System default TO UTC

            
            
            ps.setTimestamp(1, tempStart);
            ps.setTimestamp(2, tempEnd);

            
            System.out.println(ps.toString());
            
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                String tempCustName = rs.getString("customer.customerName");
                String tempCustId = rs.getString("appointment.customerId");
                String tempApptId = rs.getString("appointment.appointmentId");
                String tempTitle = rs.getString("appointment.title");
                String tempDescription = rs.getString("appointment.description");
                String tempLocation = rs.getString("appointment.location");
                String tempContact = rs.getString("appointment.contact");
                String tempURL = rs.getString("appointment.url");
                tempStart = rs.getTimestamp("appointment.start");                              //start, end url
                tempEnd = rs.getTimestamp("appointment.end");

                uniStart = ZonedDateTime.of(tempStart.toLocalDateTime(), ZoneId.of("UTC"));  //179 through 189 are for converting timestamp from database to UTC timestamp

                uniStart = uniStart.withZoneSameInstant(ZoneId.systemDefault());

                ZonedDateTime uniEnd = ZonedDateTime.of(tempEnd.toLocalDateTime(), ZoneId.of("UTC"));

                uniEnd = uniEnd.withZoneSameInstant(ZoneId.systemDefault());

                tempStart = Timestamp.valueOf(uniStart.toLocalDateTime());   //
                tempEnd = Timestamp.valueOf(uniEnd.toLocalDateTime());  //We'll to the opposite of this when putting information back into the database  - From System default TO UTC

                

                System.out.println("After appListToTable, did we make it??");
                
                
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Reminder");
                alert.setHeaderText("Appointment with " + tempCustName);
                alert.setContentText("Appointment Start Time " + tempStart.toString()); // enter apointment info here

                alert.showAndWait();
                
                

            }
        } catch (Exception e) {

        }
        
        
              }
        
       
    
    
    
}
    

