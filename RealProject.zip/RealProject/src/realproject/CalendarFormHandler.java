/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realproject;

/**
 *
 * @author Noall
 */
public class CalendarFormHandler {
    
    private String name;
    private String appointment;
    private String date;
    private String startTime;
    private String endTime;
    
    public CalendarFormHandler(String name, String appointment, String date, String startTime, String endTime) {
        
        this.name = name;
        this.appointment = appointment;
        this.date = date;
        this.startTime = startTime;
        this.endTime = endTime;
        
    }
    
    
    
    
    
}
