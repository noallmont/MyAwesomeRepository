/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realproject;

import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Noall
 */
//public class NewSceneOpener {
//    
//    public void openWindow(String newFXMLScene) throws IOException {
//        Parent home_page_parent = FXMLLoader.load(getClass().getResource(newFXMLScene));
//        Scene home_page_scene = new Scene(home_page_parent);
//        //Stage app_stage = (Stage)((Node) event.getSource()).getScene().getWindow();
//    } 
//    
//}
