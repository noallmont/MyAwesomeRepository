/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realproject;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author Noall
 */
public class UserInformationController implements Initializable {

    @FXML
    private TextField custFirstName;

    @FXML
    private TextField custLastName;

    @FXML
    private TextField custAddress;

    @FXML
    private TextField custAddress2;

    @FXML
    private TextField custZip;

    @FXML
    private TextField custCity;

    @FXML
    private TextField custCountry;

    @FXML
    private TextField custTelephone;
 
    @FXML
    private TableView<custFormHandler> custSelectTable;

    @FXML
    private TableColumn<custFormHandler, String> custIdColumnHeader;

    @FXML
    private TableColumn<custFormHandler, String> custNameColumnHeader;

    @FXML
    private CheckBox custAddBox;
    
    private static custFormHandler selectedCustomer;
    
    private boolean isNew;
    
    

    
   
   

    //@FXML
    //private Button custSubmit;
    @FXML
    private void handleButtonAction(ActionEvent event) throws IOException {

        /* Grab information from the form */
        String firstName = custFirstName.getText();
        String lastName = custLastName.getText();
        String address = custAddress.getText();
        String address2 = custAddress2.getText();
        String zip = custZip.getText();
        String city = custCity.getText();
        String country = custCountry.getText();
        String telephone = custTelephone.getText();
        

        System.out.println(firstName + " " + lastName);
        System.out.println(address + "; " + address2);
        System.out.println(city + " " + zip);
        System.out.println(country);
        System.out.println(telephone + " "); //email);
        
        //if(country.trim().isEmpty()) {
	//alert to add for empty field values
//}     
        if((country.trim().isEmpty()) 
                || (city.trim().isEmpty()) 
                || (address.trim().isEmpty()) 
                || (address2.trim().isEmpty()) 
                || (zip.trim().isEmpty()) 
                || (telephone.trim().isEmpty()) 
                || (firstName.trim().isEmpty()) 
                || (lastName.trim().isEmpty())) {
            
            Alert countryAlert = new Alert(AlertType.INFORMATION);
            countryAlert.setTitle("Missing Field");
            countryAlert.setHeaderText("Incomplete Form");
            countryAlert.setContentText("All fields are required. Please enter valid information into each form field.");
            
            countryAlert.showAndWait();
        }
        
        

        /* init variables */
        String countryId = null;
        String cityId = null;
        String addressId = null;
        String customerId = null;
        String customerName = lastName + ", " + firstName;
        String active = "1";

        /* set the connection */
        MyConnector myConn = new MyConnector();

        myConn.doTheConnection();

        Statement stmt = null;

        //Begin sequence to add information from the UserInformation form to the database
        try {

            MyConnector.getConn();
            System.out.println("Let's check the database...");

            isNew = custAddBox.isSelected();
            /* use this to update records */

            if (!isNew) {
                /* we are updating a record so grab initial informaiton */
                
                
                PreparedStatement ps = MyConnector.getConn().prepareStatement("SELECT customer.customerId,"
                        + " customer.addressId, address.cityId FROM customer JOIN address ON customer.addressId  = address.addressId WHERE customer.customerName = ?;");
                ps.setString(1, this.selectedCustomer.getName()); //changed from ps.setString(1, customerName);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    /* We get 3 of the 4 ids with one SQL statement.  It's too many joins to get all 4 */
                    customerId = rs.getString("customer.customerId");
                    addressId = rs.getString("customer.addressId");
                    cityId = rs.getString("address.cityId");

                }
                PreparedStatement getCountryId = MyConnector.getConn().prepareStatement("SELECT * FROM city WHERE cityId = ?;");
                getCountryId.setString(1, cityId);
                ResultSet countryRs = getCountryId.executeQuery();

                if (countryRs.next()) {
                    /* Pick up the country id using gthe city from above */
                    countryId = countryRs.getString("countryId");
                }
                /* here, we have customerId, addressId, cityId, and countryID */

                System.out.println("We've grabbed:" + customerId + " " + addressId + " " + cityId + " " + countryId);

            }//end if(!isNew)

            if (isNew) {
                
                
	

                try {
                    PreparedStatement ps = MyConnector.getConn().prepareStatement("SELECT * FROM country WHERE country = ?");
                    ps.setString(1, country);
                    ResultSet rs = ps.executeQuery();

                    String result; //= rs.getString("country");

                    if (rs.next()) {

                        result = rs.getString("country");

                        countryId = rs.getString("countryId");

                        System.out.println(result + " stepOne");

                    }
                } catch (SQLException sqe) {
                }
            }

            try {
                PreparedStatement countryInsert;
                //isNew = false;
                if (isNew) {
                    countryInsert = MyConnector.getConn().prepareStatement("INSERT INTO `U03p8Q`.`country` (`country`, `createDate`, `createdBy`, `lastUpdate`, `lastUpdateBy`) VALUES (?, ?, ?, ?, ?);");
                    countryInsert.setString(1, country);//this gets information into the '?' wildcard
                    countryInsert.setString(2, Timestamp.valueOf(LocalDateTime.now()).toString());
                    countryInsert.setString(3, FXMLDocumentController.getCurrentUser());
                    countryInsert.setString(4, Timestamp.valueOf(LocalDateTime.now()).toString());
                    countryInsert.setString(5, FXMLDocumentController.getCurrentUser());
                } else {
                    countryInsert = MyConnector.getConn().prepareStatement("UPDATE `U03p8Q`.`country` SET `country`=?, `createDate`=?, `createdBy`=?, `lastUpdate`=?, `lastUpdateBy`=? WHERE countryId= ?;");
                    countryInsert.setString(1, country);//this gets information into the '?' wildcard
                    countryInsert.setString(2, Timestamp.valueOf(LocalDateTime.now()).toString());
                    countryInsert.setString(3, FXMLDocumentController.getCurrentUser());
                    countryInsert.setString(4, Timestamp.valueOf(LocalDateTime.now()).toString());
                    countryInsert.setString(5, FXMLDocumentController.getCurrentUser());
                    countryInsert.setString(6, countryId);

                    System.out.println(countryInsert.toString());
                }

                countryInsert.executeUpdate();

            } catch (Exception e) {
                System.out.println("Problem");
            }
//start city ----------------------------------------------------------------------------------------------------

if (isNew) {
                try {
                    PreparedStatement ps = MyConnector.getConn().prepareStatement("SELECT * FROM country WHERE country = ?");
                    ps.setString(1, country);
                    ResultSet rs = ps.executeQuery();

                    String result; //= rs.getString("country");

                    if (rs.next()) {

                        result = rs.getString("country");

                        countryId = rs.getString("countryId");

                        System.out.println(result + " stepTwo");

                    }
                } catch (SQLException sqe) {
                }
            }



//______________________-----------------------------____________________________---------------------------------
            try {
                PreparedStatement cityInsert;
                
                //need code to get the cityID
                //isNew = false;
                if (isNew) {
                    cityInsert = MyConnector.getConn().prepareStatement("INSERT INTO `U03p8Q`.`city` (`city`, `countryId`, `createDate`, `createdBy`, `lastUpdate`, `lastUpdateBy`) VALUES (?, ?, ?, ?, ?, ?);");
                    cityInsert.setString(1, city);
                    cityInsert.setString(2, countryId);//this gets information into the '?' wildcard
                    cityInsert.setString(3, Timestamp.valueOf(LocalDateTime.now()).toString());
                    cityInsert.setString(4, FXMLDocumentController.getCurrentUser());
                    cityInsert.setString(5, Timestamp.valueOf(LocalDateTime.now()).toString());
                    cityInsert.setString(6, FXMLDocumentController.getCurrentUser());
                } else {
                    cityInsert = MyConnector.getConn().prepareStatement("UPDATE `U03p8Q`.`city` SET `city`=?, `lastUpdate`=?, `lastUpdateBy`=? WHERE cityId= ?;");
                    cityInsert.setString(1, city);//this gets information into the '?' wildcard
                    cityInsert.setString(2, Timestamp.valueOf(LocalDateTime.now()).toString());
                    cityInsert.setString(3, FXMLDocumentController.getCurrentUser());
                    cityInsert.setString(4, cityId);

                    System.out.println(cityInsert.toString());
                }

                cityInsert.executeUpdate();

            } catch (Exception e) {
                System.out.println("Problem with city");
            }
//Start Address ----------------------------------------------------------------------------------------------------
if (isNew) {
                try {
                    PreparedStatement ps = MyConnector.getConn().prepareStatement("SELECT * FROM city WHERE countryId = ?");
                    ps.setString(1, countryId);
                    ResultSet rs = ps.executeQuery();

                    String result; //= rs.getString("country");

                    if (rs.next()) {

                        result = rs.getString("city");

                        cityId = rs.getString("cityId");

                        System.out.println(result);

                    }
                } catch (SQLException sqe) {
                }
            }
//______________________-----------------------------____________________________---------------------------------


            try {
                ResultSet rs;
                PreparedStatement ps;


                try {
                    PreparedStatement addressInsert = null;
                    if(isNew){
                    addressInsert = MyConnector.getConn().prepareStatement("INSERT INTO `U03p8Q`.`address` (`address`,`address2`, `cityId`, `postalCode`,`phone`,`createDate`, `createdBy`, `lastUpdate`, `lastUpdateBy`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);");
                    addressInsert.setString(1, address);//this gets information into the '?' wildcard
                    addressInsert.setString(2, address2);
                    addressInsert.setString(3, cityId);
                    addressInsert.setString(4, zip);
                    addressInsert.setString(5, telephone);
                    addressInsert.setString(6, Timestamp.valueOf(LocalDateTime.now()).toString());
                    addressInsert.setString(7, FXMLDocumentController.getCurrentUser());
                    addressInsert.setString(8, Timestamp.valueOf(LocalDateTime.now()).toString());
                    addressInsert.setString(9, FXMLDocumentController.getCurrentUser());

                    System.out.println(addressInsert.toString());
                    }
                    else{
                        
                    addressInsert = MyConnector.getConn().prepareStatement("UPDATE `U03p8Q`.`address` SET `address`=?, `address2`=?, `cityId`=?, `postalCode`=?, `phone`=?,`lastUpdate`=?, `lastUpdateBy`=? WHERE addressId=?;");
                    addressInsert.setString(1, address);//this gets information into the '?'
                    addressInsert.setString(2, address2);
                    addressInsert.setString(3, cityId);
                    addressInsert.setString(4, zip);
                    addressInsert.setString(5, telephone);
                    addressInsert.setString(6, Timestamp.valueOf(LocalDateTime.now()).toString());
                    addressInsert.setString(7, FXMLDocumentController.getCurrentUser());
                    addressInsert.setString(8, addressId);

                    System.out.println(addressInsert.toString());
                        
                    }
                    addressInsert.executeUpdate();

                } catch (Exception e) {
                    System.out.println("Problem with address");
                    e.printStackTrace();
                }

                try {
                ps = MyConnector.getConn().prepareStatement("SELECT * FROM address WHERE address = ?");
                ps.setString(1, address);

                    rs = ps.executeQuery();

                    if (rs.next()) {

                        String result = rs.getString("address");

                        addressId = rs.getString("addressId");

                        System.out.println(result);
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(UserInformationController.class.getName()).log(Level.SEVERE, null, ex);
                    System.out.println("No addressID");
                    ex.printStackTrace();
                }

            } catch (Exception e) {
                System.out.println("Uh - oh, something happened with the Customer Info connection!city");
                e.printStackTrace();
            }
 //Start customer ----------------------------------------------------------------------------------------------------
        try{
            PreparedStatement customerInsert = null;
            if(isNew){
                customerInsert = MyConnector.getConn().prepareStatement("INSERT INTO `U03p8Q`.`customer` (`customerName`, `addressId`, `active`, `createDate`, `createdBy`, `lastUpdate`, `lastUpdateBy`) VALUES (?, ?, ?, ?, ?, ?, ?);");
                customerInsert.setString(1, customerName);
                customerInsert.setString(2, addressId);
                customerInsert.setString(3, active);
                customerInsert.setString(4, Timestamp.valueOf(LocalDateTime.now()).toString());
                customerInsert.setString(5, FXMLDocumentController.getCurrentUser());
                customerInsert.setString(6, Timestamp.valueOf(LocalDateTime.now()).toString());
                customerInsert.setString(7, FXMLDocumentController.getCurrentUser());
                
                System.out.println(customerInsert.toString());
                
            }
            else{
                customerInsert = MyConnector.getConn().prepareStatement("UPDATE `U03p8Q`.`customer` SET `customerName`=?, `addressId`=?, `active`=?, `lastUpdate`=?, `lastUpdateBy`=? WHERE `customerId`=?");//
                customerInsert.setString(1, customerName);
                customerInsert.setString(2, addressId);
                customerInsert.setString(3, active);
                customerInsert.setString(4, Timestamp.valueOf(LocalDateTime.now()).toString());
                customerInsert.setString(5, FXMLDocumentController.getCurrentUser());
                customerInsert.setString(6, customerId);
                
                System.out.println(customerInsert.toString());
            }
            customerInsert.executeUpdate();
            
        }
        catch(Exception e){
            System.out.println("Problem with customer");
            e.printStackTrace();
        }
        


    }
    catch (Exception e) {
        System.out.println("Uh - oh, something happened with the Customer Info connection!customer");
        e.printStackTrace();
    }
        
        updateRecord();

}
@FXML
        public void updateRecord() {
            
            custSelectTable.getItems().setAll(custListToTable());
            
            custSelectTable.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue)-> custFieldPopulate(newValue));
            
            
        
    }
    /**
     * Initializes the controller class.
     */
    @Override
        public void initialize(URL url, ResourceBundle rb) {
            
            for(custFormHandler e:custListToTable()){
                
               
            System.out.println(e.getName());
            
            }
            
            custIdColumnHeader.setCellValueFactory(new PropertyValueFactory<>("customerId"));
            custNameColumnHeader.setCellValueFactory(new PropertyValueFactory<>("name"));
            
            custSelectTable.getItems().setAll(custListToTable());
            
            custSelectTable.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue)-> custFieldPopulate(newValue));
            
            
            
        
    }
    //This should populate the form fields with customer information from the database    
        @FXML
    private void custFieldPopulate (custFormHandler selectedCustomer) {   

        
        if( selectedCustomer != null){
        String fullName = selectedCustomer.getName();
        this.selectedCustomer = selectedCustomer;
        
        String last = fullName.substring(0, fullName.indexOf(","));
	String first = fullName.substring(fullName.indexOf(",") + 1, fullName.length()).trim();
        
	custFirstName.setText(first);//need to clarify firstname and last name
	custLastName.setText(last);//Need to clarify firstname and lastname
	custAddress.setText(selectedCustomer.getAddress());
	custAddress2.setText(selectedCustomer.getAddress2());
	custZip.setText(selectedCustomer.getZip());
	custCity.setText(selectedCustomer.getCity());
	custCountry.setText(selectedCustomer.getCountry());
	custTelephone.setText(selectedCustomer.getTelephone());
        }else
            custFieldClearer();
    }    
    
    
    @FXML
    
    public void custFieldClearer() {
	
                
	custFirstName.clear();//need to clarify firstname and last name
	custLastName.clear();//Need to clarify firstname and lastname
	custAddress.clear();
	custAddress2.clear();
	custZip.clear();
	custCity.clear();
	custCountry.clear();
	custTelephone.clear();
    }    


    
        
    public static ArrayList<custFormHandler> custListToTable() {
        ArrayList<custFormHandler> tableViewPopulator  = new ArrayList<>();
        
        
        try {
            PreparedStatement ps = MyConnector.getConn().prepareStatement("SELECT customer.customerId, customer.customerName, address.address, address.address2, "
                    + "address.postalCode, address.phone, city.city, country.country "
                    + "FROM customer, address, city, country "
                    + "WHERE customer.addressId = address.addressId "
                    + "AND address.cityId = city.cityId AND country.countryId = city.countryId;");
            
            System.out.println(ps.toString());
            
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                
                String tempCustId = rs.getString("customer.customerId");
                String tempCustName = rs.getString("customer.customerName");
                String tempAddress = rs.getString("address.address");
                String tempAddress2 = rs.getString("address.address2");
                String tempZip = rs.getString("address.postalCode");
                String tempPhone = rs.getString("address.phone");
                String tempCity = rs.getString("city.city");
                String tempCountry = rs.getString("country.country");
                
                tableViewPopulator.add(new custFormHandler(tempCustId, tempCustName, tempAddress, tempAddress2, tempZip, tempCity, tempCountry,tempPhone));
                
            }
        }
        catch(Exception e){
            
            
            
        }
        return tableViewPopulator;
    }    

}
