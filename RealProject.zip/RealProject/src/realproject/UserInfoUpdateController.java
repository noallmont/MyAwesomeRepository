/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realproject;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Noall
 */
public class UserInfoUpdateController implements Initializable {

    @FXML
    private TextField custFirstName;

    @FXML
    private TextField custLastName;

    @FXML
    private TextField custStreet;
    
    @FXML
    private TextField custStreet2;

    @FXML
    private TextField cust_apt;

    @FXML
    private TextField custZip;

    @FXML
    private TextField custCity;

    @FXML
    private TextField custState;

    @FXML
    private TextField custCountry;

    @FXML
    private TextField custTelephone;

    @FXML
    private TextField custEmail;
   
    @FXML
    private Button custUpdate;

    //@FXML
    //private Button custSubmit;
    @FXML
    private void handleButtonAction(ActionEvent event) throws IOException {

        String firstName = custFirstName.getText();
        String lastName = custLastName.getText();
        String address = custStreet.getText();
        String address2 = custStreet2.getText();
        String apt = cust_apt.getText();
        String zip = custZip.getText();
        String city = custCity.getText();
        String state = custState.getText();
        String country = custCountry.getText();
        String telephone = custTelephone.getText();
        String email = custEmail.getText();

        System.out.println(firstName + " " + lastName);
        System.out.println(address + " " + apt);
        System.out.println(city + " " + state + " " + zip);
        System.out.println(country);
        System.out.println(telephone + " " + email);

        String countryId = null;
        String cityId = null;
        String addressId = null;
        String customerId = null;
        String customerName = lastName + ", " +firstName;
        String active = "1";

        MyConnector myConn = new MyConnector();

        myConn.doTheConnection();

        Statement stmt = null;
        
        //Begin sequence to add information from the UserInformation form to the database
        
        try {

            MyConnector.getConn();
            System.out.println("Let's check the database...");

            PreparedStatement ps = MyConnector.getConn().prepareStatement("SELECT * FROM country WHERE country = ?");
            ps.setString(1, country);
            ResultSet rs = ps.executeQuery();

            String result; //= rs.getString("country");

            if (rs.next()) {

                result = rs.getString("country");

                countryId = rs.getString("countryId");

                System.out.println(result);

            } else {
                try {
                    PreparedStatement countryInsert = MyConnector.getConn().prepareStatement("UPDATE `U03p8Q`.`country` (`country`, `createDate`, `createdBy`, `lastUpdate`, `lastUpdateBy`) VALUES (?, ?, ?, ?, ?);");
                    countryInsert.setString(1, country);//this gets information into the '?' wildcard
                    countryInsert.setString(2, Timestamp.valueOf(LocalDateTime.now()).toString());
                    countryInsert.setString(3, FXMLDocumentController.getCurrentUser());
                    countryInsert.setString(4, Timestamp.valueOf(LocalDateTime.now()).toString());
                    countryInsert.setString(5, FXMLDocumentController.getCurrentUser());

                    countryInsert.executeUpdate();

                } catch (Exception e) {
                    System.out.println("Problem");
                }

                try {
                    rs = ps.executeQuery();

                    if (rs.next()) {

                        result = rs.getString("country");

                        countryId = rs.getString("countryId");

                        System.out.println(result);
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(UserInfoUpdateController.class.getName()).log(Level.SEVERE, null, ex);
                    System.out.println("No countryID");
                }

            }

        } catch (Exception e) {
            System.out.println("Uh - oh, something happened with the Customer Update country connection!");
            e.printStackTrace();
        }
        try {

            MyConnector.getConn();
            System.out.println("Let's check the database...");

            PreparedStatement ps = MyConnector.getConn().prepareStatement("SELECT * FROM city WHERE city = ?");
            ps.setString(1, city);
            ResultSet rs = ps.executeQuery();

            String result; //= rs.getString("country");

            if (rs.next()) {

                result = rs.getString("city");

                cityId = rs.getString("cityId");

                System.out.println(result);

            } else {
                try {
                    PreparedStatement cityInsert = MyConnector.getConn().prepareStatement("INSERT INTO `U03p8Q`.`city` (`city`, `countryId`, `createDate`, `createdBy`, `lastUpdate`, `lastUpdateBy`) VALUES (?, ?, ?, ?, ?, ?);");
                    cityInsert.setString(1, city);//this gets information into the '?' wildcard
                    cityInsert.setString(2, countryId);
                    cityInsert.setString(3, Timestamp.valueOf(LocalDateTime.now()).toString());
                    cityInsert.setString(4, FXMLDocumentController.getCurrentUser());
                    cityInsert.setString(5, Timestamp.valueOf(LocalDateTime.now()).toString());
                    cityInsert.setString(6, FXMLDocumentController.getCurrentUser());

                    System.out.println(cityInsert.toString());
                    
                    cityInsert.executeUpdate();
                    
                    

                } catch (Exception e) {
                    System.out.println("Problem with city");
                }

                try {
                    rs = ps.executeQuery();

                    if (rs.next()) {

                        result = rs.getString("city");

                        cityId = rs.getString("cityId");

                        System.out.println(result);
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(UserInfoUpdateController.class.getName()).log(Level.SEVERE, null, ex);
                    System.out.println("No cityID");
                }

            }

        } catch (Exception e) {
            System.out.println("Uh - oh, something happened with the Customer Update City connection!");
            e.printStackTrace();
        }
try {

            MyConnector.getConn();
            System.out.println("Let's check the database...");

            PreparedStatement ps = MyConnector.getConn().prepareStatement("SELECT * FROM address WHERE address = ?");
            ps.setString(1, address);
            ResultSet rs = ps.executeQuery();

            String result; //= rs.getString("country");

            if (rs.next()) {

                result = rs.getString("address");

                addressId = rs.getString("addressId");

                System.out.println(result);

            } else {
                try {
                    PreparedStatement addressInsert = MyConnector.getConn().prepareStatement("INSERT INTO `U03p8Q`.`address` (`address`,`address2`, `cityId`, `postalCode`,`phone`,`createDate`, `createdBy`, `lastUpdate`, `lastUpdateBy`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);");
                    addressInsert.setString(1, address);//this gets information into the '?' wildcard
                    addressInsert.setString(2, address2);
                    addressInsert.setString(3, cityId);
                    addressInsert.setString(4, zip);
                    addressInsert.setString(5, telephone);
                    addressInsert.setString(6, Timestamp.valueOf(LocalDateTime.now()).toString());
                    addressInsert.setString(7, FXMLDocumentController.getCurrentUser());
                    addressInsert.setString(8, Timestamp.valueOf(LocalDateTime.now()).toString());
                    addressInsert.setString(9, FXMLDocumentController.getCurrentUser());

                    System.out.println(addressInsert.toString());
                    
                    addressInsert.executeUpdate();

                } catch (Exception e) {
                    System.out.println("Problem with address");
                    e.printStackTrace();
                }

                try {
                    rs = ps.executeQuery();

                    if (rs.next()) {

                        result = rs.getString("address");

                        addressId = rs.getString("addressId");

                        System.out.println(result);
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(UserInfoUpdateController.class.getName()).log(Level.SEVERE, null, ex);
                    System.out.println("No addressID");
                    ex.printStackTrace();
                }
                

            }


} catch (Exception e) {
            System.out.println("Uh - oh, something happened with the Customer Info address connection!");
            e.printStackTrace();
        }

try {

            MyConnector.getConn();
            System.out.println("Let's check the database...");

            PreparedStatement ps = MyConnector.getConn().prepareStatement("SELECT * FROM customer WHERE customerName = ?");
            ps.setString(1, customerName);
            ResultSet rs = ps.executeQuery();

            String result; //= rs.getString("country");

            if (rs.next()) {

                result = rs.getString("customerName");

                customerId = rs.getString("customerId");

                System.out.println(result);

            } else {
                try {
                    PreparedStatement customerInsert = MyConnector.getConn().prepareStatement("INSERT INTO `U03p8Q`.`customer` (`customerName`, `addressId`, `active`, `createDate`, `createdBy`, `lastUpdate`, `lastUpdateBy`) VALUES (?, ?, ?, ?, ?, ?, ?);");
                    customerInsert.setString(1, customerName);//this gets information into the '?' wildcard
                    customerInsert.setString(2, addressId);
                    customerInsert.setString(3, active);
                    customerInsert.setString(4, Timestamp.valueOf(LocalDateTime.now()).toString());
                    customerInsert.setString(5, FXMLDocumentController.getCurrentUser());
                    customerInsert.setString(6, Timestamp.valueOf(LocalDateTime.now()).toString());
                    customerInsert.setString(7, FXMLDocumentController.getCurrentUser());

                    customerInsert.executeUpdate();

                } catch (Exception e) {
                    System.out.println("Problem with customer");
                    e.printStackTrace();
                }

                try {
                    rs = ps.executeQuery();

                    if (rs.next()) {

                        result = rs.getString("customerName");

                        customerId = rs.getString("customerId");

                        System.out.println(result);
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(UserInfoUpdateController.class.getName()).log(Level.SEVERE, null, ex);
                    System.out.println("No customerID");
                }

            }
}

catch (Exception e) {
            System.out.println("Uh - oh, something happened with the Customer Update customer connection!");
            e.printStackTrace();
        }


    
    
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
