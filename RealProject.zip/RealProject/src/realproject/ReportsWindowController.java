/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realproject;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextInputDialog;

/**
 * FXML Controller class
 *
 * @author Noall
 */
public class ReportsWindowController implements Initializable {
    
    @FXML
    private Button schedButton;

    @FXML
    private Button typesButton;

    @FXML
    private Button tbdButton;
    
    @FXML
    private void handleTypesButton(ActionEvent event) throws IOException {
        
        List<String> months = new ArrayList<>();
            months.add("January");
            months.add("February");
            months.add("March");
            months.add("April");
            months.add("May");
            months.add("June");
            months.add("July");
            months.add("August");
            months.add("September");
            months.add("October");
            months.add("November");
            months.add("December");

        ChoiceDialog<String> dialog = new ChoiceDialog<>("January", months);
        //If no value is set, enter January
            dialog.setTitle("Appointment Type Report");
            
            dialog.setContentText("Choose the month:");

            Optional<String> result = dialog.showAndWait();

            String monthName = result.get();
            
            
           
            
        TextInputDialog yearField = new TextInputDialog("year");
        //Gets text entry from year field
        Optional<String> yearResult = yearField.showAndWait();
        
        
        String year = yearResult.get();
        
        System.out.println("Did we make it?" + year);
        
        
        
        
        try (BufferedWriter apptWriter = new BufferedWriter(new FileWriter(new File("Appt_Type_Report.TXT")))) {
            
            try {
//            PreparedStatement ps = MyConnector.getConn().prepareStatement("SELECT count(title), "
//                    + "appointment.title FROM U03p8Q.appointment "
//                    + "WHERE month(appointment.start) = ? group by appointment.title;");

            apptWriter.write("Number of Appointments by Type During " + monthName + " " + year);
            apptWriter.newLine();
            apptWriter.newLine();
            apptWriter.write("Title\t" + "Number of Appointments");
            apptWriter.newLine();
            apptWriter.newLine();


            PreparedStatement ps = MyConnector.getConn().prepareStatement("SELECT"
                    + " count(title), appointment.title FROM U03p8Q.appointment "
                    + "WHERE month(appointment.start) = ? "
                    + "AND year(appointment.start) = ? group by appointment.title;");
            
            
            ps.setInt(1, getMonthValue(monthName));
            ps.setString(2, year);
            
            System.out.println(ps.toString());
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                
                String text = rs.getString("appointment.title");
                text += "\t" + rs.getString("count(title)");
                apptWriter.write(text);
                apptWriter.newLine();
                
                System.out.println(text);

            }
        } catch (IOException e) {

        }
            
            
        }
        catch(Exception e){
        
        }

        
            
    
        
        
        
        
    }
    
    @FXML //
    private void handleSchedButton(ActionEvent event) throws IOException {
        
        ArrayList<String> custNames = new ArrayList<>();

        for (custFormHandler c : UserInformationController.custListToTable()) {

            custNames.add(c.getName());

        }

        for (String s : custNames) {
            System.out.println(s);
        }

        ChoiceDialog<String> dialog = new ChoiceDialog<>("Customer", custNames);
        dialog.setTitle("Customer");
        dialog.setHeaderText("Choose customer for appointment");
        dialog.setContentText("Please select");

        Optional<String> result = dialog.showAndWait();
        
        if (result.isPresent()){
            
            System.out.println("..WHEEEE " + result.get());
}
        
        //String customer;
        String customer = result.get();
        
        System.out.println(customer);

        
        
        try (BufferedWriter custyWriter = new BufferedWriter(new FileWriter(new File("Custy_Appt_Report.TXT")))) {
            
            try {
//            
            custyWriter.write("Appointments for selected Customer: " + customer);
            custyWriter.newLine();
            custyWriter.newLine();
            custyWriter.write("Name\t" + "Title\t" + "Desc\t" + "Start\t" + "End\t");
            custyWriter.newLine();
            custyWriter.newLine();
            

            PreparedStatement ps = MyConnector.getConn().prepareStatement(
                    "SELECT customer.customerName, appointment.customerId, appointment.title, appointment.description, "
                            + "appointment.start, appointment.end FROM U03p8Q.appointment, U03p8Q.customer "
                            + "WHERE appointment.customerId = customer.customerId AND customer.customerName = ?;");
            
            
            ps.setString(1, customer);
            
            System.out.println(ps.toString());
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                
                String text = rs.getString("customer.customerName");
                text += "\t" + rs.getString("appointment.title");
                text += "\t" + rs.getString("appointment.description");
                text += "\t" + rs.getString("appointment.start");
                text += "\t" + rs.getString("appointment.end");
                custyWriter.write(text);
                custyWriter.newLine();
                
                System.out.println(text);

            }
        } catch (Exception e) {

        }
            
            
        }
        catch(IOException e){
        
        
        }
        
        
        
    }
    
    @FXML
    private void handleTbdButton(ActionEvent event) throws IOException {
        
        System.out.println("Button Pressed");
        
        
         try (BufferedWriter apptWriter = new BufferedWriter(new FileWriter(new File("Custy_List_Report.TXT")))) {
            
            try {
//            PreparedStatement ps = MyConnector.getConn().prepareStatement("SELECT count(title), "
//                    + "appointment.title FROM U03p8Q.appointment "
//                    + "WHERE month(appointment.start) = ? group by appointment.title;");

            apptWriter.write("Customer List by Name");
            apptWriter.newLine();
            apptWriter.newLine();
            apptWriter.write("Customer Name\t" + "Customer ID");
            apptWriter.newLine();
            apptWriter.newLine();


            PreparedStatement ps = MyConnector.getConn().prepareStatement("SELECT "
                    + "customerName, customerId FROM customer ORDER BY customerName; ");
            
            
                       
            System.out.println(ps.toString());
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                
                String text = rs.getString("customer.customerName");
                text += "\t" + rs.getString("customer.customerId");
                apptWriter.write(text);
                apptWriter.newLine();
                
                System.out.println(text);

            }
        } catch (IOException e) {

        }
            
            
        }catch(Exception e){
            
        }
        
        
        
        
        
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

public int getMonthValue(String s) {
    
    System.out.println(s);
    
    if( s.equalsIgnoreCase("January")){
        return 1;
    }else if( s.equalsIgnoreCase("February")){
        return 2;
    }else if( s.equalsIgnoreCase("March")){
        return 3;
    }else if( s.equalsIgnoreCase("April")){
        return 4;
    }else if( s.equalsIgnoreCase("May")){
        return 5;
    }else if( s.equalsIgnoreCase("June")){
        return 6;
    }else if( s.equalsIgnoreCase("July")){
        return 7;
    }else if( s.equalsIgnoreCase("August")){
        return 8;
    }else if( s.equalsIgnoreCase("September")){
        return 9;
    }else if( s.equalsIgnoreCase("October")){
        return 10;
    }else if( s.equalsIgnoreCase("November")){
        return 11;
    }else if( s.equalsIgnoreCase("December")){
        return 12;
    }else{
        return -1;
    }
    
   
    
}
    
    
}
