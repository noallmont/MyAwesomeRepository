/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realproject;

import java.io.IOException;
import static java.lang.reflect.Array.get;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import static java.time.temporal.TemporalQueries.localTime;
import java.util.ArrayList;
import static java.util.Date.UTC;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author Noall
 */
public class AppointmentWindowController implements Initializable {

    @FXML
    private TableView<ApptFormHandler> apptTableView;

    @FXML
    private TableColumn<ApptFormHandler, String> apptIdColumn;

    @FXML
    private TableColumn<ApptFormHandler, String> custNameColumn;

    @FXML
    private TableColumn<ApptFormHandler, String> startTimeColumn;

    @FXML
    private TextField apptTitle;

    @FXML
    private TextField apptDescription;

    @FXML
    private TextField apptLocation;

    @FXML
    private TextField apptContact;

    @FXML
    private DatePicker apptStartingDate;

    @FXML
    private DatePicker apptEndingDate;

    @FXML
    private TextField apptStartHour;

    @FXML
    private TextField apptStartMinute;

    @FXML
    private TextField apptEndingHour;

    @FXML
    private TextField apptEndingMinute;

    @FXML
    private TextField apptURL;

    @FXML
    private Button apptSubmit;

    @FXML
    private CheckBox apptNewCheck;

    @FXML
    private Button apptDelete;

    private boolean isNew;

    private static String customerId;

    private static String apptId;

    @FXML
    private void handleButtonAction(ActionEvent event) throws IOException {

        if (!apptValidate()) {
            return;
        }

        String ctrlTitle = apptTitle.getText();
        String ctrlDescription = apptDescription.getText();
        String ctrlLocation = apptLocation.getText();
        String ctrlContact = apptContact.getText();
        LocalDate ctrlStartingDate = apptStartingDate.getValue(); //datepicker returns localDate object
        LocalDate ctrlEndingDate = apptEndingDate.getValue(); //datepicker returns localDate object

        int ctrlStartHour = Integer.parseInt(apptStartHour.getText()); 
        int ctrlStartMinute = Integer.parseInt(apptStartMinute.getText()); 
        int ctrlEndingHour = Integer.parseInt(apptEndingHour.getText()); 
        int ctrlEndingMinute = Integer.parseInt(apptEndingMinute.getText()); 
        String ctrlURL = apptURL.getText();

//        String apptAppointmentId = null;
//        String apptCustomerId = null;
//        String apptCustomerName = null;

        
        //see method below, this validates user input
        LocalDateTime startTime = LocalDateTime.of(ctrlStartingDate, LocalTime.of(ctrlStartHour, ctrlStartMinute));
        LocalDateTime endTime = LocalDateTime.of(ctrlEndingDate, LocalTime.of(ctrlEndingHour, ctrlEndingMinute));

        System.out.println(ctrlStartHour);
        System.out.println(ctrlStartMinute);

        ZonedDateTime uniStart = ZonedDateTime.of(startTime, ZoneId.systemDefault());
        uniStart = uniStart.withZoneSameInstant(ZoneId.of("UTC"));

        ZonedDateTime uniEndTime = ZonedDateTime.of(endTime, ZoneId.systemDefault());
        uniEndTime = uniEndTime.withZoneSameInstant(ZoneId.of("UTC"));  //Changed from uniStart.withZoneSameInstant(ZoneId.of("UTC")); 

        try {

            PreparedStatement appointmentInsert;
            //isNew = false;

            if (isNew) {
                appointmentInsert = MyConnector.getConn().prepareStatement("INSERT INTO `U03p8Q`.`appointment` (`customerId`, `title`, `description`,"
                        + " `location`, `contact`, `url`, `start`, `end`, `createDate`, `createdBy`, `lastUpdate`, `lastUpdateBy`) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);");
                appointmentInsert.setString(1, customerId);
                appointmentInsert.setString(2, ctrlTitle);
                appointmentInsert.setString(3, ctrlDescription);
                appointmentInsert.setString(4, ctrlLocation);
                appointmentInsert.setString(5, ctrlContact);
                appointmentInsert.setString(6, ctrlURL);
                appointmentInsert.setTimestamp(7, Timestamp.valueOf(uniStart.toLocalDateTime()));
                appointmentInsert.setTimestamp(8, Timestamp.valueOf(uniEndTime.toLocalDateTime()));
                appointmentInsert.setString(9, Timestamp.valueOf(LocalDateTime.now()).toString());
                appointmentInsert.setString(10, FXMLDocumentController.getCurrentUser());
                appointmentInsert.setString(11, Timestamp.valueOf(LocalDateTime.now()).toString());
                appointmentInsert.setString(12, FXMLDocumentController.getCurrentUser());

                System.out.println(appointmentInsert.toString());

                //appointmentInsert.executeUpdate();
            } else {
                appointmentInsert = MyConnector.getConn().prepareStatement("UPDATE `U03p8Q`.`appointment` SET `title`=?, `description`=?, `location`=?, `contact`=?, `url`=?, `start`=?, `end`=?, `lastUpdate`=?, `lastUpdateBy`=? WHERE `appointmentId`= ?;");
                appointmentInsert.setString(1, ctrlTitle);//this gets information into the '?' wildcard
                appointmentInsert.setString(2, ctrlDescription);
                appointmentInsert.setString(3, ctrlLocation);
                appointmentInsert.setString(4, ctrlContact);
                appointmentInsert.setString(5, ctrlURL);
                appointmentInsert.setTimestamp(6, Timestamp.valueOf(uniStart.toLocalDateTime()));
                appointmentInsert.setTimestamp(7, Timestamp.valueOf(uniEndTime.toLocalDateTime()));
                appointmentInsert.setString(8, Timestamp.valueOf(LocalDateTime.now()).toString());
                appointmentInsert.setString(9, FXMLDocumentController.getCurrentUser());
                appointmentInsert.setString(10, apptId);

                System.out.println(appointmentInsert.toString());
            }

            appointmentInsert.executeUpdate();
            
            

        } catch (Exception e) {
            System.out.println("Problem");
        }
        
        apptTableView.getItems().setAll(apptListToTable());

        apptTableView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> apptFieldPopulate(newValue));

    }

    //SpinnerValueFactory<Integer> apptHour = new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 23, 0);
    //this.apptStartHour.setValueFactory(apptHour);
    //SELECT customer.customerName, appointment.customerId, appointment.appointmentId, appointment.title, appointment.description, appointment.location, appointment.contact, appointment.url, appointment.start, appointment.end FROM customer, appointment WHERE appointment.customerId = customer.customerId;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        for (ApptFormHandler e : apptListToTable()) {

            System.out.println(e.getCustomerName());

        }

        apptIdColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentId"));
        custNameColumn.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        startTimeColumn.setCellValueFactory(new PropertyValueFactory<>("start"));

        apptTableView.getItems().setAll(apptListToTable());

        apptTableView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> apptFieldPopulate(newValue));

    }

    public static ArrayList<ApptFormHandler> apptListToTable() {

        ArrayList<ApptFormHandler> tableViewPopulator = new ArrayList<>();

        try {
            PreparedStatement ps = MyConnector.getConn().prepareStatement("SELECT customer.customerName, appointment.customerId, "
                    + "appointment.appointmentId, appointment.title, appointment.description, appointment.location, "
                    + "appointment.contact, appointment.url, appointment.start, appointment.end "
                    + "FROM customer, appointment WHERE appointment.customerId = customer.customerId;");

            System.out.println(ps.toString());

            System.out.println("Let's populate this table!");
            //we make it this far at least!

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                String tempCustName = rs.getString("customer.customerName");
                String tempCustId = rs.getString("appointment.customerId");
                String tempApptId = rs.getString("appointment.appointmentId");
                String tempTitle = rs.getString("appointment.title");
                String tempDescription = rs.getString("appointment.description");
                String tempLocation = rs.getString("appointment.location");
                String tempContact = rs.getString("appointment.contact");
                String tempURL = rs.getString("appointment.url");
                Timestamp tempStart = rs.getTimestamp("appointment.start");                              //start, end url
                Timestamp tempEnd = rs.getTimestamp("appointment.end");

                ZonedDateTime uniStart = ZonedDateTime.of(tempStart.toLocalDateTime(), ZoneId.of("UTC"));  

                uniStart = uniStart.withZoneSameInstant(ZoneId.systemDefault());

                ZonedDateTime uniEnd = ZonedDateTime.of(tempEnd.toLocalDateTime(), ZoneId.of("UTC"));

                uniEnd = uniEnd.withZoneSameInstant(ZoneId.systemDefault());

                tempStart = Timestamp.valueOf(uniStart.toLocalDateTime());   
                tempEnd = Timestamp.valueOf(uniEnd.toLocalDateTime()); 

                tableViewPopulator.add(new ApptFormHandler(tempCustName, tempCustId, tempApptId, tempTitle,
                        tempDescription, tempLocation, tempContact, tempURL, tempStart, tempEnd));

                

            }
        } catch (Exception e) {

        }
        return tableViewPopulator;
    }

    @FXML
       private void apptFieldPopulate(ApptFormHandler selectedAppt) {   // ***

        if( selectedAppt != null){
        apptTitle.setText(selectedAppt.getTitle());
        apptDescription.setText(selectedAppt.getDescription());
        apptLocation.setText(selectedAppt.getLocation());
        apptContact.setText(selectedAppt.getContact());
        apptURL.setText(selectedAppt.getUrl());
        apptStartingDate.setValue(selectedAppt.startReturn().toLocalDate());
        apptStartHour.setText(selectedAppt.startHour());
        apptStartMinute.setText(selectedAppt.startMinute());
        apptEndingDate.setValue(selectedAppt.endReturn().toLocalDate());
        apptEndingHour.setText(selectedAppt.endHour());
        apptEndingMinute.setText(selectedAppt.endMinute());

        apptId = selectedAppt.getAppointmentId();
        }else{
            clearForm();
        }

    }
    
    private void clearForm(){
         apptTitle.clear();

        apptDescription.clear();

        apptLocation.clear();

        apptContact.clear();
        
        apptURL.clear();
        
        this.apptStartHour.clear();
        
        this.apptStartMinute.clear();
        
        this.apptEndingHour.clear();
        
        this.apptEndingMinute.clear();
        
        this.apptStartingDate.setValue(LocalDate.now());
        
        this.apptEndingDate.setValue(LocalDate.now());

    }

    @FXML
    private void newApptAlert() {

        System.out.println("newApptAlert!");
        
        if( this.apptNewCheck.isSelected()){

        isNew = true;
        clearForm();
       
        ArrayList<String> custNames = new ArrayList<>();

        for (custFormHandler c : UserInformationController.custListToTable()) {

            custNames.add(c.getName());

        }

        for (String s : custNames) {
            System.out.println(s);
        }

        ChoiceDialog<String> dialog = new ChoiceDialog<>("Customer", custNames);
        dialog.setTitle("Customer");
        dialog.setHeaderText("Choose customer for appointment");
        dialog.setContentText("Please select");

        Optional<String> result = dialog.showAndWait();

        result.ifPresent(custSelect -> customerId = getCustId(custSelect));
        }else{
            isNew = false;
        }

    }

    private String getCustId(String name) {

        try {
            PreparedStatement ps = MyConnector.getConn().prepareStatement("SELECT * FROM customer WHERE customerName = ?");
            ps.setString(1, name);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                return rs.getString("customerId");

            }
        } catch (SQLException ex) {
            Logger.getLogger(AppointmentWindowController.class.getName()).log(Level.SEVERE, null, ex);
        }

        return null;

    }

    private boolean apptValidate() {

        try {

            String ctrlTitle = apptTitle.getText();
            String ctrlDescription = apptDescription.getText();
            String ctrlLocation = apptLocation.getText();
            String ctrlContact = apptContact.getText();
            LocalDate ctrlStartingDate = apptStartingDate.getValue(); //datepicker returns localDate object
            LocalDate ctrlEndingDate = apptEndingDate.getValue(); //datepicker returns localDate object


            int ctrlStartHour = Integer.parseInt(apptStartHour.getText()); //
            int ctrlStartMinute = Integer.parseInt(apptStartMinute.getText()); //
            int ctrlEndingHour = Integer.parseInt(apptEndingHour.getText()); //
            int ctrlEndingMinute = Integer.parseInt(apptEndingMinute.getText());

            LocalDateTime startTime = LocalDateTime.of(ctrlStartingDate, LocalTime.of(ctrlStartHour, ctrlStartMinute));
            LocalDateTime endTime = LocalDateTime.of(ctrlEndingDate, LocalTime.of(ctrlEndingHour, ctrlEndingMinute));
//         catch (NumberFormatException e) {

            String ctrlURL = apptURL.getText();

            if ((ctrlTitle.trim().isEmpty())
                    || (ctrlDescription.trim().isEmpty())
                    || (ctrlLocation.trim().isEmpty())
                    || (ctrlContact.trim().isEmpty())
                    || (apptStartHour.getText().trim().isEmpty())
                    || (apptStartMinute.getText().trim().isEmpty())
                    || (apptEndingHour.getText().trim().isEmpty())
                    || (apptEndingMinute.getText().trim().isEmpty())) {

                Alert apptAlert = new Alert(AlertType.INFORMATION);
                apptAlert.setTitle("Missing Field");
                apptAlert.setHeaderText("Incomplete Form");
                apptAlert.setContentText("All fields are required. Please enter valid information into each form field.");

                apptAlert.showAndWait();

                return false;
            }

            if ((ctrlStartHour < 8 || ctrlStartHour > 17)
                    || (ctrlEndingHour < 8 || ctrlEndingHour > 17)
                    || (ctrlStartMinute < 0 || ctrlStartMinute > 59)
                    || (ctrlEndingMinute < 0 || ctrlEndingMinute > 59)
                    || (ctrlEndingHour == 17 && ctrlEndingMinute > 0)) {

                Alert timeAlert = new Alert(AlertType.INFORMATION);
                timeAlert.setTitle("Invalid Time");
                timeAlert.setHeaderText("Invalid time entered");
                timeAlert.setContentText("Please enter a valid time between 8 AM and 5 PM");

                timeAlert.showAndWait();

                return false;
            }

            if ((ctrlStartHour > ctrlEndingHour) //If the start hour is before the ending hour

                    || ((ctrlStartHour == ctrlEndingHour)
                    && (ctrlStartMinute >= ctrlEndingMinute))) { //if the start hour and end hour are the same, the start minute must be before the end minute

                Alert apptAlert = new Alert(AlertType.INFORMATION);
                apptAlert.setTitle("Invalid Entry");
                apptAlert.setHeaderText("Incorrect Time Format");
                apptAlert.setContentText("Please check Appointment Time. Start Time must be at least 1 minute before end time.");

                apptAlert.showAndWait();
                
                return false;

            }

            try {
                
                ZonedDateTime zStart = ZonedDateTime.of(startTime, ZoneId.systemDefault());
                ZonedDateTime zEnd = ZonedDateTime.of(endTime, ZoneId.systemDefault());
                
                zStart = zStart.withZoneSameInstant(ZoneId.of("UTC"));
                zEnd = zEnd.withZoneSameInstant(ZoneId.of("UTC"));

                PreparedStatement ps = MyConnector.getConn().prepareStatement("SELECT * FROM U03p8Q.appointment WHERE appointmentId != ? AND (start BETWEEN ? AND ? OR end BETWEEN ? and ?);");

                
                ps.setString(1, apptId);
                ps.setTimestamp(2, Timestamp.valueOf(zStart.toLocalDateTime()));
                ps.setTimestamp(3, Timestamp.valueOf(zEnd.toLocalDateTime()));
                ps.setTimestamp(4, Timestamp.valueOf(zStart.toLocalDateTime()));
                ps.setTimestamp(5, Timestamp.valueOf(zEnd.toLocalDateTime()));
                
                
                
                System.out.println(ps.toString());
                
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    
                    System.out.println("This appointment overlaps!!");
                    
                    Alert apptAlert = new Alert(AlertType.INFORMATION);
                    apptAlert.setTitle("Invalid Entry");
                    apptAlert.setHeaderText("Invalid Time");
                    apptAlert.setContentText("Please check Appointment Time. Appointments may not overlap.");

                    apptAlert.showAndWait();
                    
                    return false;
                }

            } catch (SQLException ex) {

                Logger.getLogger(AppointmentWindowController.class.getName()).log(Level.SEVERE, null, ex);

            }
        } catch (NumberFormatException e) {
            Alert emptyTimeAlert = new Alert(AlertType.INFORMATION);
            emptyTimeAlert.setTitle("Invalid Time");
            emptyTimeAlert.setHeaderText("Invalid time");
            emptyTimeAlert.setContentText("Please enter a valid time between 8 AM and 5 PM");

            emptyTimeAlert.showAndWait();
        }

        return true;
    }

    @FXML
    private void deleteAppt() {

        try {
            PreparedStatement ps = MyConnector.getConn().prepareStatement("DELETE FROM appointment WHERE appointmentId = ?");
            ps.setString(1, apptId);
            System.out.println(ps.toString());

            System.out.println("Let's delete this appointment");
            //we make it this far at least!

            ps.executeUpdate(); //

        } catch (SQLException ex) {
            Logger.getLogger(AppointmentWindowController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        apptTableView.getItems().setAll(apptListToTable());

        apptTableView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> apptFieldPopulate(newValue));
    }

}
