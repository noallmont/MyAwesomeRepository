/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realproject;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Noall
 */

public class HomeSceneController implements Initializable {
    
    
    @FXML
    private Button userIdButton;

    @FXML
    private Button appointmentsButton;

    @FXML
    private Button CalendarButton;
    
    @FXML
    private Button reportButton;
    
    //appointmentsButton
    @FXML
    private void handleAppointmentButton(ActionEvent event) throws IOException {
        
        System.out.println("Opening Appointments");
        
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("AppointmentWindow.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("AppointmentWindow");
            stage.setScene(new Scene(root1));
            stage.show();
        } catch (Exception e) {
            System.out.println("Can't load AppointmentWindow!");
            System.out.println(e);
        }
    }
    //opens User Information window
    @FXML
    private void handleButtonAction(ActionEvent event) throws IOException {
        
        System.out.println("Opening User Information");
        
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("UserInformation.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("User Information");
            stage.setScene(new Scene(root1));
            stage.show();
        } catch (Exception e) {
            System.out.println("Can't load UserInformation window!");
            System.out.println(e);
        }
    }
    
    //opens Calendar window
    @FXML
    private void handleCalendarButton(ActionEvent event) throws IOException {
        
        System.out.println("Opening Calendar");
        
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("CalendarWindow.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("CalendarWindow");
            stage.setScene(new Scene(root1));
            stage.show();
        } catch (Exception e) {
            System.out.println("Can't load Calendar window!");
            System.out.println(e);
        }
    }
    
    //Opens Report Window
    @FXML
    private void handleReportButton(ActionEvent event) throws IOException {
        
        System.out.println("Opening Reports");
        
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("ReportsWindow.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("ReportsWindow");
            stage.setScene(new Scene(root1));
            stage.show();
        } catch (Exception e) {
            System.out.println("Can't load ReportWindow!");
            System.out.println(e);
        }
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
