/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realproject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


/**
 *
 * @author Noall
 */
public class MyConnector { //doesn't seem to be picking this up. It's coming from the old simpledbtester package
    
    String DB_URL; //= "jdbc:mysql://52.206.157.109/U03p8Q";
    String USERNAME; //= "U03p8Q";
    String PASSWORD; //= "53688046122";
    
    private static Connection conn;
    
    public static Connection getConn () {
        return conn;
    }
    
    
    public void doTheConnection() {
        DB_URL = "jdbc:mysql://52.206.157.109/U03p8Q";
        USERNAME = "U03p8Q";
        PASSWORD = "53688046122";
        
        //Connection conn = null; this is replaced by line 23
        Statement stmt = null;
        
        try {
            conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            System.out.println(" **BOO-YAH** You are connected to the database!");
        }
        catch (Exception e) {
            System.out.println(" **SEPPUKU** The stakes are high."); //They sure are
        }
        
    
    }
    
    
}
