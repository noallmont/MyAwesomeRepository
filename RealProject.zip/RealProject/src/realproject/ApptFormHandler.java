/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package realproject;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 *
 * @author Noall
 */
public class ApptFormHandler {

    private String customerName;
    private String customerId;
    private String appointmentId;
    private String title;
    private String description;
    private String location;
    private String contact;
    private String url;
    private Timestamp start;
    private Timestamp end;
    
    
    
     public ApptFormHandler(String customerName, String customerId, String appointmentId, String title, String description, String location, String contact, String url, Timestamp start, Timestamp end) {
        this.customerName = customerName;
        this.customerId = customerId;
        this.appointmentId = appointmentId;
        this.title = title;
        this.description = description;
        this.location = location;
        this.contact = contact;
        this.url = url;
        this.start = start;
        this.end = end;
    }
    
    

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(String appointmentId) {
        this.appointmentId = appointmentId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Timestamp getStart() {
        return start;
    }

    public void setStart(Timestamp start) {
        this.start = start;
    }

    public Timestamp getEnd() {
        return end;
    }

    public void setEnd(Timestamp end) {
        this.end = end;
    }
    
    public LocalDateTime startReturn() {
        return start.toLocalDateTime();
    }
    
    public LocalDateTime endReturn() {
        return end.toLocalDateTime();   

   
    
    }
    
    public String startHour() {
        Integer hour = start.toLocalDateTime().getHour();
        return hour.toString();
    }
    
    public String startMinute() {
        Integer minute = start.toLocalDateTime().getMinute();
        return minute.toString();
    }
    
    public String endHour() {
        Integer hour = end.toLocalDateTime().getHour();
        return hour.toString();
    }
    
    public String endMinute() {
        Integer minute = end.toLocalDateTime().getMinute();
        return minute.toString();
    }

}


    //SELECT customer.customerName, appointment.customerId, appointment.appointmentId, appointment.title, appointment.description, appointment.location, appointment.contact, appointment.url, appointment.start, appointment.end FROM customer, appointment WHERE appointment.customerId = customer.customerId;
